# ECharts

<a href="http://echarts.baidu.com">
    <img style="vertical-align: top;" src="./asset/logo.png?raw=true" alt="logo" height="50px">
</a>

ECharts is a free, powerful charting and visualization library offering an easy way of adding intuitive, interactive, and highly customizable charts to your commercial products. It is written in pure JavaScript and based on <a href="https://github.com/ecomfe/zrender">zrender</a>, which is a whole new lightweight canvas library.

## Get ECharts

+ Download on [echarts.baidu.com](http://echarts.baidu.com/download.html)
+ `npm install echarts --save`

## Docs

+ [Tutorial](http://echarts.baidu.com/tutorial.html)
    + [中文](http://echarts.baidu.com/tutorial.html)
    + [English](http://ecomfe.github.io/echarts-doc/public/en/tutorial.html)

+ [API](http://echarts.baidu.com/api.html)
    + [中文](http://echarts.baidu.com/api.html)
    + [English](http://ecomfe.github.io/echarts-doc/public/en/api.html)

+ [Option Manual](http://echarts.baidu.com/option.html)
    + [中文](http://echarts.baidu.com/option.html)
    + [English](http://ecomfe.github.io/echarts-doc/public/en/option.html)

## Resources

### Awesome ECharts 

[https://github.com/ecomfe/awesome-echarts](https://github.com/ecomfe/awesome-echarts)

### Extensions

+ [百度地图扩展](https://github.com/ecomfe/echarts/tree/master/extension/bmap)

+ [字符云 wordcloud](https://github.com/ecomfe/echarts-wordcloud)

+ [Graph Modularity](https://github.com/ecomfe/echarts-graph-modularity) Graph modularity extension for community detection

+ [leaflet-echarts](https://github.com/wandergis/leaflet-echarts3) by wandergis
+ [arcgis-echarts](https://github.com/wandergis/arcgis-echarts3) by wandergis

#### AngularJS Binding

+ [angular-echarts](https://github.com/wangshijun/angular-echarts) by wangshijun
+ [echarts-ng](https://github.com/bornkiller/echarts-ng) by bornkiller
+ [ng-echarts](https://github.com/liekkas/ng-echarts) by liekkas

#### Vue Component

+ [vue-echarts](https://github.com/Justineo/vue-echarts) by Justineo
+ [vue-echarts](https://github.com/panteng/vue-echarts) by panteng

#### React Component

+ [echarts-for-react](https://github.com/hustcc/echarts-for-react) by hustcc
+ [react-echarts](https://github.com/somonus/react-echarts) by somonus
+ [re-echarts](https://github.com/liekkas/re-echarts) by liekkas


### Other Languages
#### Python

+ [echarts-python](https://github.com/yufeiminds/echarts-python) by yufeiminds
+ [krisk](https://github.com/napjon/krisk) by napjon

#### R

+ [recharts](https://github.com/taiyun/recharts) by taiyun
+ [recharts](https://github.com/yihui/recharts) by yihui
+ [ECharts2Shiny](https://github.com/XD-DENG/ECharts2Shiny) by XD-DENG

#### Julia

+ [ECharts.jl](https://github.com/randyzwitch/ECharts.jl) by randyzwitch

#### PureScript

+ [purescript-echarts](https://github.com/slamdata/purescript-echarts/)

#### iOS

+ [iOS-Echarts](https://github.com/Pluto-Y/iOS-Echarts) by Pluto-Y

#### Java

+ [ECharts-Java](http://www.oschina.net/p/echarts-java) by Liuzh_533

#### .NET

+ [EChartsSDK](https://github.com/idoku/EChartsSDK) by idoku

#### PHP

+ [Echarts-PHP](https://github.com/hisune/Echarts-PHP) by hisune


## License
Copyright (c) 2013, Baidu Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the FreeBSD Project.
